/// <reference types="vite/client" />

declare const __DEV__: boolean;
